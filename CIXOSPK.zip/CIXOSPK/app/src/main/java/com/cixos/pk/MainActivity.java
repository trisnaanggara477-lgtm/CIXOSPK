package com.cixos.pk;
import android.content.Context;
import android.hardware.camera2.CameraManager;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private boolean flashlight = false;
    private CameraManager cameraManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        EditText user = findViewById(R.id.user);
        EditText pass = findViewById(R.id.pass);
        Button login = findViewById(R.id.login);
        Button senter = findViewById(R.id.senter);
        TextView jadwal = findViewById(R.id.jadwal);

        login.setOnClickListener(v -> {
            if(user.getText().toString().equals("admin") && pass.getText().toString().equals("1234")) {
                Toast.makeText(this, "Login berhasil", Toast.LENGTH_SHORT).show();
                jadwal.setText("Sholat Tangerang\nSubuh: 04:32\nDzuhur: 11:45\nAshar: 15:00\nMaghrib: 17:58\nIsya: 19:08");
            } else {
                Toast.makeText(this, "Username/password salah", Toast.LENGTH_SHORT).show();
            }
        });

        senter.setOnClickListener(v -> {
            try {
                flashlight =!flashlight;
                String cameraId = cameraManager.getCameraIdList()[0];
                cameraManager.setTorchMode(cameraId, flashlight);
                senter.setText(flashlight? "MATIIN SENTER" : "NYALAIN SENTER");
            } catch (Exception e) {
                Toast.makeText(this, "Senter error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
